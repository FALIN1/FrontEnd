
  # Front End

  This is a code bundle for Front End. The original project is available at https://www.figma.com/design/0fMgURyvOnBNMTBERnmZ2o/Front-End.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  